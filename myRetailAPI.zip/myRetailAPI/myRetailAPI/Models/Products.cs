﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace myRetailAPI.Models
{
    public class Products
    {

        public long ProdID { get; set; }
        public string ItemName { get; set; }

        public string Price { get; set; }
        


    }
}
